
import React from 'react';
import { AnalysisResult } from '../types';

interface AnalysisViewProps {
  result: AnalysisResult;
  onReset: () => void;
}

export const AnalysisView: React.FC<AnalysisViewProps> = ({ result, onReset }) => {
  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-blue-400">Analysis Found</h2>
        <button 
          onClick={onReset}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm transition-colors border border-slate-700"
        >
          Analyze Another
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700">
          <p className="text-slate-400 text-xs uppercase tracking-wider font-semibold mb-1">Language</p>
          <p className="text-lg font-mono text-emerald-400">{result.language}</p>
        </div>
        <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 col-span-2">
          <p className="text-slate-400 text-xs uppercase tracking-wider font-semibold mb-1">Error Type</p>
          <p className="text-lg font-semibold text-rose-400">{result.errorType}</p>
        </div>
      </div>

      <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700">
        <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
          <svg className="w-5 h-5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          Explanation
        </h3>
        <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">
          {result.explanation}
        </p>
      </div>

      <div className="bg-slate-950 p-6 rounded-2xl border border-slate-700 shadow-xl overflow-hidden">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold text-emerald-400 flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Corrected Code
          </h3>
          <button 
            onClick={() => navigator.clipboard.writeText(result.correctedCode)}
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1 bg-slate-800 px-2 py-1 rounded"
          >
            Copy
          </button>
        </div>
        <pre className="bg-black/50 p-4 rounded-lg overflow-x-auto text-sm font-mono text-slate-300 border border-slate-800">
          <code>{result.correctedCode}</code>
        </pre>
      </div>
    </div>
  );
};
