
import React, { useState, useCallback, useRef } from 'react';
import { analyzeCodeError } from './services/geminiService';
import { AnalysisView } from './components/AnalysisView';
import { AnalysisResult } from './types';

const App: React.FC = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Reset states
    setError(null);
    setResult(null);

    // Create preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setPreview(reader.result as string);
    };
    reader.readAsDataURL(file);

    // Analyze
    setIsAnalyzing(true);
    try {
      const base64 = await new Promise<string>((resolve) => {
        const r = new FileReader();
        r.onload = () => resolve(r.result as string);
        r.readAsDataURL(file);
      });
      const analysis = await analyzeCodeError(base64);
      setResult(analysis);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to analyze the image. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const reset = () => {
    setResult(null);
    setPreview(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col p-4 md:p-8">
      {/* Header */}
      <header className="max-w-6xl mx-auto w-full mb-12 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">CodeLens <span className="text-blue-500">AI</span></h1>
            <p className="text-slate-500 text-xs font-medium uppercase">Visual Error Debugger</p>
          </div>
        </div>
        <div className="hidden md:block">
          <a 
            href="https://ai.google.dev" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-slate-400 hover:text-white transition-colors text-sm flex items-center gap-2"
          >
            Powered by Gemini
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
            </svg>
          </a>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto w-full">
        {!result && !isAnalyzing ? (
          <div className="flex flex-col items-center justify-center min-h-[50vh] text-center space-y-8 animate-in fade-in duration-700">
            <div className="space-y-4 max-w-xl">
              <h2 className="text-4xl md:text-5xl font-extrabold text-white leading-tight">
                Debug your code with <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-indigo-500">computer vision.</span>
              </h2>
              <p className="text-slate-400 text-lg">
                Upload a screenshot of your code editor and error message. 
                Our AI will identify the bug and provide a fix in seconds.
              </p>
            </div>

            <div 
              onClick={triggerFileInput}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const file = e.dataTransfer.files[0];
                if (file) {
                  const input = fileInputRef.current;
                  if (input) {
                    const dataTransfer = new DataTransfer();
                    dataTransfer.items.add(file);
                    input.files = dataTransfer.files;
                    handleFileChange({ target: input } as any);
                  }
                }
              }}
              className="w-full max-w-2xl aspect-video md:aspect-[2/1] bg-slate-800/50 border-2 border-dashed border-slate-700 rounded-3xl flex flex-col items-center justify-center gap-4 cursor-pointer hover:bg-slate-800 hover:border-blue-500/50 transition-all group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-b from-blue-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="w-16 h-16 bg-slate-700 rounded-2xl flex items-center justify-center group-hover:scale-110 group-hover:bg-blue-600 transition-all duration-300">
                <svg className="w-8 h-8 text-slate-300 group-hover:text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <div className="space-y-1">
                <p className="font-semibold text-lg text-slate-200">Click or drag screenshot here</p>
                <p className="text-slate-500 text-sm">PNG, JPG or WebP (Max 10MB)</p>
              </div>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                accept="image/*"
              />
            </div>
          </div>
        ) : isAnalyzing ? (
          <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-6">
            <div className="relative">
              <div className="w-24 h-24 border-4 border-blue-500/20 rounded-full animate-pulse" />
              <div className="absolute inset-0 w-24 h-24 border-t-4 border-blue-500 rounded-full animate-spin" />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-xl font-bold text-white">Analyzing Error...</h3>
              <p className="text-slate-400">Gemini is scanning your code for bugs.</p>
            </div>
            {preview && (
              <div className="w-full max-w-md rounded-xl overflow-hidden shadow-2xl border border-slate-700 opacity-50 filter blur-[1px]">
                <img src={preview} alt="Preview" className="w-full h-auto" />
              </div>
            )}
          </div>
        ) : result ? (
          <AnalysisView result={result} onReset={reset} />
        ) : null}

        {error && (
          <div className="mt-8 p-4 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-start gap-3 animate-in slide-in-from-top-2">
            <svg className="w-5 h-5 text-rose-500 mt-0.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <div className="space-y-1">
              <p className="font-bold text-rose-500">Error Analyzing Image</p>
              <p className="text-rose-400 text-sm">{error}</p>
              <button 
                onClick={reset}
                className="text-xs font-bold text-rose-400 underline hover:text-rose-300"
              >
                Try again
              </button>
            </div>
          </div>
        )}
      </main>

      <footer className="mt-20 py-8 border-t border-slate-800 text-center text-slate-500 text-sm">
        <p>© {new Date().getFullYear()} CodeLens AI. Created for developers by a World-Class Engineer.</p>
      </footer>
    </div>
  );
};

export default App;
