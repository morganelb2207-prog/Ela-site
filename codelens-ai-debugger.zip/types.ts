
export interface AnalysisResult {
  language: string;
  errorType: string;
  explanation: string;
  correctedCode: string;
  originalProblem: string;
}

export interface HistoryItem {
  id: string;
  timestamp: number;
  image?: string;
  result: AnalysisResult;
}
