
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from "../types";

export const analyzeCodeError = async (imageBase64: string): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        parts: [
          {
            text: `Analyze this screenshot of a code editor and error message. 
            Identify the programming language, the specific line causing the error, 
            explain exactly why it happened (e.g. string termination, mismatched quotes), 
            and provide the corrected version of the code. 
            Return the result in JSON format.`
          },
          {
            inlineData: {
              mimeType: "image/png",
              data: imageBase64.split(',')[1] || imageBase64
            }
          }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          language: { type: Type.STRING },
          errorType: { type: Type.STRING },
          explanation: { type: Type.STRING },
          correctedCode: { type: Type.STRING },
          originalProblem: { type: Type.STRING }
        },
        required: ["language", "errorType", "explanation", "correctedCode", "originalProblem"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("Failed to get analysis from Gemini");
  
  return JSON.parse(text) as AnalysisResult;
};
